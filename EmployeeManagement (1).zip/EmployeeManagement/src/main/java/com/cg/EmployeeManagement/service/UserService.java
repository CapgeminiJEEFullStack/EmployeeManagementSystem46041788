package com.cg.EmployeeManagement.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.EmployeeManagement.exceptions.ApplicationException;
import com.cg.EmployeeManagement.exceptions.BusinessException;
import com.cg.EmployeeManagement.exceptions.DatabaseOperationException;
import com.cg.EmployeeManagement.model.User;

import com.cg.EmployeeManagement.repository.UserRepository;
@Service
public class UserService {
	@Autowired
	private UserRepository userRepository;

	public User insertUser(User user) {
		// TODO Auto-generated method stub
		return userRepository.save(user);
	}

	public void deleteUserbyId(User user) {
		userRepository.delete(user);
	}

	public List<User> getAllUsers() {
		List<User> list = userRepository.findAll();

		return list;

	}

	public User validateUser(User user) throws BusinessException, DatabaseOperationException, ApplicationException {
		Optional<User> user1 = userRepository.findById(Integer.parseInt(user.getUserid()));
		return user1.get();
	}

}
