package com.cg.EmployeeManagement.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cg.EmployeeManagement.exceptions.ApplicationException;
import com.cg.EmployeeManagement.exceptions.DatabaseOperationException;
import com.cg.EmployeeManagement.model.Department;
import com.cg.EmployeeManagement.repository.DepartmentRepository;
@Transactional
@Service
public class DepartmentService {

	@Autowired
	private DepartmentRepository departmentRepo;

	public Department addDepartment(Department department) throws ApplicationException, DatabaseOperationException {
		return departmentRepo.save(department);
	}
	
	public List<Department> getAllDepartmentsDetails() throws ApplicationException, DatabaseOperationException{     
		return departmentRepo.findAll();
	}

	public List<Department> getAllDepartmentDetailsByPagination() throws ApplicationException, DatabaseOperationException{
		return departmentRepo.findAll();       

	}
	public long getAllDepartmentCount() {
		return departmentRepo.count();     
	}

	public void deleteDepart(int departid) throws ApplicationException, DatabaseOperationException{
		departmentRepo.deleteById(departid);
	}
}