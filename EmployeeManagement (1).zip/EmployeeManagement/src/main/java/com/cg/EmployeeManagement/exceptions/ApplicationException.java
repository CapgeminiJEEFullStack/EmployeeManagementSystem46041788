package com.cg.EmployeeManagement.exceptions;

public class ApplicationException extends Exception{

}
