package com.cg.EmployeeManagement.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.cg.EmployeeManagement.model.Compliance;
import com.cg.EmployeeManagement.model.StatusReport;
import com.cg.EmployeeManagement.exceptions.ApplicationException;
import com.cg.EmployeeManagement.exceptions.BusinessException;
import com.cg.EmployeeManagement.exceptions.DatabaseOperationException;
import com.cg.EmployeeManagement.service.ComplianceService;





@RestController
@RequestMapping("/compliancee")
public class ComplianceController {
	@Autowired
	ComplianceService complianceService;
@PostMapping("/createRL")
public ResponseEntity<Compliance> add(@RequestBody Compliance compliance) {

	try {
		Compliance 	retCompliance = complianceService.createRL(compliance);
		return new ResponseEntity<Compliance>(retCompliance, HttpStatus.OK);
	} catch (DatabaseOperationException | ApplicationException | BusinessException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return null;
	}
	
}


@GetMapping("/all")
public List<Compliance> findAll(){
	try {
		return complianceService.getAllRL();
	} catch (DatabaseOperationException | ApplicationException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return null;
	}
	}


@GetMapping("/{complianceId}")
public List<Compliance> find(@PathVariable int complianceId) {

	try {
		return complianceService.getAllRL(complianceId);
	} catch (DatabaseOperationException | ApplicationException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return null;
	}
}@PostMapping("/createStatusReport")
public ResponseEntity<StatusReport> add(@RequestBody StatusReport statusReport) {

	try {
		StatusReport retstatus =complianceService.createStatusReport(statusReport);
		return new ResponseEntity<StatusReport>(retstatus, HttpStatus.OK);
	} catch (DatabaseOperationException | ApplicationException | BusinessException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return null;
	}
}
	@GetMapping("/{userId}")

	public List<StatusReport> find(@PathVariable int userId,int complianceId) {
		
		try {
			return complianceService.getAllStatusReport(userId, complianceId);
		} catch (DatabaseOperationException | ApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
}
}