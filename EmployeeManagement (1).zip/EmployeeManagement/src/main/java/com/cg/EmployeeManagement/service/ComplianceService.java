package com.cg.EmployeeManagement.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cg.EmployeeManagement.model.Compliance;
import com.cg.EmployeeManagement.model.StatusReport;
import com.cg.EmployeeManagement.repository.ComplianceRepository;
import com.cg.EmployeeManagement.repository.StatusReportRepository;
import com.cg.EmployeeManagement.exceptions.ApplicationException;
import com.cg.EmployeeManagement.exceptions.BusinessException;
import com.cg.EmployeeManagement.exceptions.DatabaseOperationException;

import java.util.ArrayList;
@Transactional
@Service
public class ComplianceService{

	
	@Autowired
	private ComplianceRepository complianceRepository;
	private StatusReportRepository statusRepository;
	
	
	public Compliance createRL(Compliance compliance)  throws DatabaseOperationException, ApplicationException, BusinessException{
		
		
			return complianceRepository.save(compliance);
		
	}

	
	public List<Compliance> getAllRL() throws DatabaseOperationException, ApplicationException {
		
				return complianceRepository.findAll();


	}
	
	public List<Compliance> getAllRL(int complianceId)  throws DatabaseOperationException, ApplicationException{
		
		return complianceRepository.findByComplainceId(complianceId);
		
	}
	
	
	public StatusReport createStatusReport(StatusReport statusReport)
			throws DatabaseOperationException, ApplicationException, BusinessException {
		
			return statusRepository.save(statusReport);
			
	}


	public List<StatusReport> getAllStatusReport(int userId, int complainceId)
			throws DatabaseOperationException, ApplicationException {
		
		return statusRepository.findByUserIdAndComplainceId(userId, complainceId);
		
	}
	
}