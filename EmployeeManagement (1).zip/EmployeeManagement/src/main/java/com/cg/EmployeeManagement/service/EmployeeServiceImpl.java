package com.cg.EmployeeManagement.service;

import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.EmployeeManagement.exceptions.ApplicationException;
import com.cg.EmployeeManagement.exceptions.BusinessException;
import com.cg.EmployeeManagement.exceptions.DatabaseOperationException;
import com.cg.EmployeeManagement.model.Employee;
import com.cg.EmployeeManagement.repository.IEmployeeRepository;


@Service
public class EmployeeServiceImpl {
	
	@Autowired
	IEmployeeRepository employeeRepository;


	public Employee addEmployee(Employee employee)
			throws DatabaseOperationException, ApplicationException, BusinessException 
	{
	
		Employee emp = employeeRepository.save(employee);
		if(emp==null)
		{
			throw new BusinessException("Already exists");
		}
		return emp;
	}


	public boolean deleteEmployee(int empId) throws DatabaseOperationException, ApplicationException, BusinessException 
	{
	
		
		return false;
	}


	public Employee updateEmployee(Employee employee) throws DatabaseOperationException, ApplicationException, BusinessException 
	{
	
		if(employeeRepository.findById(employee.getUserId())!=null)
		{
			return employeeRepository.save(employee);
			
		}
		else
		{
		return null;
		}
	}


	public List<Employee> getAllEmployees() throws DatabaseOperationException, ApplicationException 
	{
		
		return employeeRepository.findAll();
	}


	public List<Employee> getEmployeeById(int userId) throws DatabaseOperationException, ApplicationException 
	{
		
		return (List<Employee>) employeeRepository.getEmployeeById(userId);
	}

/*	@Override
	public boolean daysBetween(Date startDate, Date endDate) 
	{
	
		return false;
	}*/


	public List<Employee> getAllEmployeesByPagination(String maxPage, String ofset) throws DatabaseOperationException, ApplicationException 
	{
		
		return null;
	}


	public Long getAllEmployeeCount() throws DatabaseOperationException, ApplicationException 
	{
		
		return (long) employeeRepository.getAllEmployeeCount();
	}

}
