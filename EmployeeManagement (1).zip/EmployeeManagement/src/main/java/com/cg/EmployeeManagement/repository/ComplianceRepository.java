package com.cg.EmployeeManagement.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.EmployeeManagement.model.Compliance;
import java.util.List;
@Repository
public interface ComplianceRepository extends JpaRepository<Compliance, Integer>{
@Query(" from Compliance where complianceId=:complianceId")
	public List<Compliance> findByComplainceId(@Param("complianceId")int complianceId);
}	