package com.cg.EmployeeManagement.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.EmployeeManagement.exceptions.ApplicationException;
import com.cg.EmployeeManagement.exceptions.BusinessException;
import com.cg.EmployeeManagement.exceptions.DatabaseOperationException;
import com.cg.EmployeeManagement.model.Employee;

public interface IEmployeeRepository extends JpaRepository<Employee, Integer> {

	@SuppressWarnings("unchecked")
	public Employee addEmployee(Employee employee)
			throws DatabaseOperationException, ApplicationException, BusinessException;

	public boolean deleteEmployee(int empId) throws DatabaseOperationException, ApplicationException;

	public Employee updateEmployee(Employee employee)
			throws DatabaseOperationException, ApplicationException, BusinessException;

	public List<Employee> getAllEmployees() throws DatabaseOperationException, ApplicationException;

	public Employee getEmployeeById(int userId) throws DatabaseOperationException, ApplicationException;

	public boolean daysBetween(Date startDate, Date endDate);

	public List<Employee> getAllEmployeesByPagination(String maxPage, String ofset)
			throws DatabaseOperationException, ApplicationException;

	public int getAllEmployeeCount() throws DatabaseOperationException, ApplicationException;

	public Employee deleteEmployee(Employee employeeEntity);
}