package com.example.demo;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.mockito.junit.jupiter.MockitoExtension;

import com.cg.EmployeeManagement.model.Compliance;

import com.cg.EmployeeManagement.model.StatusReport;
import com.cg.EmployeeManagement.exceptions.ApplicationException;
import com.cg.EmployeeManagement.exceptions.BusinessException;
import com.cg.EmployeeManagement.exceptions.DatabaseOperationException;
import com.cg.EmployeeManagement.repository.ComplianceRepository;
import com.cg.EmployeeManagement.repository.StatusReportRepository;
import com.cg.EmployeeManagement.service.ComplianceService;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;


@ExtendWith(MockitoExtension.class)
	public class ComplianceTest {
		@InjectMocks
		private ComplianceService complianceService;
@Mock
private StatusReportRepository statusRepository;
		@Mock
		private ComplianceRepository complianceRepository;
		
		
		@Test
		 void testcreaterl() throws DatabaseOperationException, ApplicationException, BusinessException  {
			
			Compliance compliance = Mockito.mock(Compliance.class);
			Compliance updated=Mockito.mock(Compliance.class);
			Mockito.when(complianceRepository.save(compliance)).thenReturn(updated); 
			Compliance result =complianceService.createRL(compliance);
			assertEquals(updated,result);

		}
		
		@Test
		void testgetallrlbyid() throws DatabaseOperationException, ApplicationException  {
			
			List<Compliance> list = new ArrayList<>();
			Compliance s1 = mock(Compliance.class);
			Compliance s2 = mock(Compliance.class);
			Compliance s3 = mock(Compliance.class);
			list.add(s1);
			list.add(s2);
			list.add(s3);
			int complianceId = 10;
			when(complianceRepository. findByComplainceId(complianceId )).thenReturn(list);
			List<Compliance> actual = complianceService.getAllRL(complianceId);
			Assertions.assertEquals(list.size(), actual.size());
			
			


		}
		@Test
		public void testgetallRL() throws DatabaseOperationException, ApplicationException
		{
			List<Compliance> list = new ArrayList<>();
			Compliance s1 = mock(Compliance.class);
			Compliance s2 = mock(Compliance.class);
			Compliance s3 = mock(Compliance.class);
			list.add(s1);
			list.add(s2);
			list.add(s3);
			when(complianceRepository.findAll()).thenReturn(list);
			List<Compliance> actual = complianceService.getAllRL();
			Assertions.assertEquals(list, actual);
			verify(complianceRepository).findAll();

		
		}
		@Test
		 void testcreatestatus() throws DatabaseOperationException, ApplicationException, BusinessException  {
				
				StatusReport statusReport = Mockito.mock(StatusReport.class);
				StatusReport updated=Mockito.mock(StatusReport.class);
				Mockito.when(statusRepository.save(statusReport)).thenReturn(updated); 
				StatusReport result =complianceService.createStatusReport( statusReport);
				assertEquals(updated,result);

			}
		@Test
		void testgetallstatus() throws DatabaseOperationException, ApplicationException {
			List<StatusReport> list = new ArrayList<>();
			StatusReport s1 = mock(StatusReport.class);
			StatusReport s2 = mock(StatusReport.class);
			StatusReport s3 = mock(StatusReport.class);
			list.add(s1);
			list.add(s2);
			list.add(s3);
			int userId = 10;
			int complianceId =10;
			when(statusRepository.findByUserIdAndComplainceId(userId, complianceId)).thenReturn(list);
			List<StatusReport> actual = complianceService.getAllStatusReport(userId, complianceId);
			Assertions.assertEquals(list.size(), actual.size());
			

		}
}